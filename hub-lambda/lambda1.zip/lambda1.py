import json


def lambda_handler(event, context):

    print("Welcome to Lambda 1")

    return "Lambda 1"
