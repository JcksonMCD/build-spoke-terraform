import json


def lambda_handler(event, context):

    print("Welcome to Lambda 2")

    return "Lambda 2"

